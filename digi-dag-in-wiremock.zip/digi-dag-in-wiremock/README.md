![Java](https://img.shields.io/static/v1?message=Java&logo=java&labelColor=D0A384&color=1182c3&logoColor=black&label=%20&style=plastic)
![11](https://img.shields.io/badge/_11-lightgrey)
![Springboot](https://img.shields.io/static/v1?message=Springboot&logo=springboot&labelColor=6DB33F&color=1182c3&logoColor=white&label=%20&style=plastic)
![2.7.0](https://img.shields.io/badge/_2.7.0-lightgrey)
![Wiremock](https://img.shields.io/static/v1?message=Wiremock&logo=wearos&labelColor=black&color=1182c3&logoColor=white&label=%20&style=plastic)
![3.1.2](https://img.shields.io/badge/_3.1.2-lightgrey)
![Openshift](https://img.shields.io/static/v1?message=Openshift&logo=REDHATOPENSHIFT&labelColor=EE0000&color=1182c3&logoColor=white&label=%20&style=plastic)
![CodeCommit](https://img.shields.io/static/v1?message=CodeCommit&logo=amazonaws&labelColor=232F3E&color=1182c3&logoColor=white&label=%20&style=plastic)

Table of Contents
=================

* [About The Project](#about-the-project)
  * [Built With](#built-with)
* [Getting Started](#getting-started)
    * [Installation](#installation)
* [Usage](#usage)
* [Roadmap](#roadmap)
* [Contact](#contact)
* [Useful Links](#useful-links)  
  


## About The Project

Most of the time we develop APIs which calls another API or external systems. There are times when 
the backend API might not be ready to integrate when we are in the process of development.  

It is the place where this utility serves the need to mock any backend response(s).  

It doesn't understand SOAP or REST call. For wiremock, you just need to pass the HTTP methods, 
and it will provide you the response either in JSON or in XML based on your need and configuration.

  

### Built With

This project is build upon below languages/frameworks.

* [Java](https://www.java.com/en/)
* [Springboot](https://spring.io/projects/spring-boot)
* [Wiremock](https://wiremock.org/)
  

## Getting Started
### Installation

_Please follow the below instruction to run the application in your local machine._

1. Clone the repo
   ```sh
   git clone ssh://git-codecommit.ap-southeast-1.amazonaws.com/v1/repos/digi-dag-in-wiremock
   ```
2. Checkout the `develop` branch.
   ```sh
   git checkout develop
   ```
3. Run a clean install.
   ```sh
   mvn clean install
   ```
3. Run the program.
   ```sh
   mvn spring-boot:run
   ```   
  

## Usage

Wiremock basically picks configurations from 2 folders.  
1. `mappings` : It contains JSON files, which specifies the mappings of request to response files  
_e.g._ :  

```json
{
    "request": {
        "method": "POST",
        "url": "/DAG/wiremock/cims/account/getAccountProfile"
    },
    "response": {
        "status": 200,
        "bodyFileName": "CIM/GetAccount/200_GetAccount.xml",
        "headers": {
          "Content-Type": "application/xml"
        }
    }
}
```  
  

`method`: HTTP method for backend.  
`url`: Url in which wiremock will respond to the request.  
`status`: The HTTP status mock should return (_e.g.: 200, 400, 500_).  
`bodyFileName`: The mocked response message (JSON or XML) that wiremock should return to the request.  
`headers`: Expected headers in the response message.  
  

2. `__files` : It contains the mock response message.  
_e.g._ :  

```xml
<?xml version="1.0" encoding="utf-8"?>
<QueryAccountResponse>
    <ResultOfOperation>
        <resultCode>0</resultCode>
        <resultMessage>success</resultMessage>
        <beId>102</beId>
        <transactionId>8748yuhuhhghfegufg</transactionId>
    </ResultOfOperation>
    <AccountInfo>
        <customerFlag>0</customerFlag>
        <customerId>74478787</customerId>
        <corporateId/>
        <title>1</title>
        <accountName>Test</accountName>
        <converge_flag>1</converge_flag>
        <email>abc@gmail.com</email>
        <AddressInfos>
            <addressType>3</addressType>
            <address1>NO 01</address1>
            <address2>JALAN DELIMA 1/1 SUBANG HI-TECH INDUSTRIAL PARK</address2>
            <address3>address3</address3>
            <addressCountry>1458</addressCountry>
            <addressProvince>MYS_14</addressProvince>
            <addressCity>c421</addressCity>
            <addressPostCode>40000</addressPostCode>
            <smsNo>8987777788</smsNo>
        </AddressInfos>
    </AccountInfo>
</QueryAccountResponse>
```  
  

No JAVA code changes required for wiremock to respond with your mocks.  
Just keep the mapping file(s) under `mappings` folder and mock response under `__files` folder and restart the service.

  

## Roadmap

- [ ] &nbsp; Externalized the `__files` and `mappings` folder for easy access.


  

## Contact

[@Any Lead](mailto:pramodk@celcomsolutions.com) - For any suggestions or improvements.

Project Link: [digi-dag-in-wiremock](https://ap-southeast-1.console.aws.amazon.com/codesuite/codecommit/repositories/digi-dag-in-wiremock/browse?region=ap-southeast-1)


  

## Useful Links

* [Project Repository](https://ap-southeast-1.console.aws.amazon.com/codesuite/codecommit/repositories/digi-dag-in-wiremock/browse?region=ap-southeast-1)
* [Project Pipelines](https://console-openshift-console.apps.nonprod.cloudocp.digi.com.my/pipelines/ns/pipelines)
* [Available Containers](https://console-openshift-console.apps.nonprod.cloudocp.digi.com.my/k8s/all-namespaces/pods)
* [Kibana](https://kibana-openshift-logging.apps.nonprod.cloudocp.digi.com.my/app/kibana)
* [CSG 3.0 Application Designs](https://digimy.atlassian.net/wiki/spaces/MAIN/pages/1652163213/Low+Level+Design)  
